package com.example.androidpartefinal.ui.dao;

import com.example.androidpartefinal.ui.activity.Medicos;

import java.util.ArrayList;
import java.util.List;

public class MedicoDAO {

    private final static List<Medico> medicos = new Arrayslist<>();
    public void salva(Medico medicoCriado) {
        medicos.add(medico);

    }

    public List<Medicos> todos() {
        return new ArrayList<>(medicos);
    }
}
