package com.example.androidpartefinal.ui.activity;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import com.example.androidpartefinal.R;
import com.example.androidpartefinal.ui.dao.MedicoDAO;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class OutraTela extends AppCompatActivity {

    Button botaoVoltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Lista de Médicos");
        setContentView(R.layout.activity_outra_tela);

        setTitle("Outra Tela Solicitada");

        botaoVoltar=findViewById(R.id.btnVoltar);

        botaoVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            finish();
            }
        });
    }
    protected void onCreated(@Nullable Bundle savedIntanceState){
        super.onCreate(savedIntanceState);
        setContentView(R.layout.activity_outra_tela);
        MedicoDAO dao= new MedicoDAO();


        List<String> medicos = new ArrayList<>(
                Arrays.asList("Dr Alex", "Dr Fran", "Dr José", "Dr Geraldo","Dr Patricia"));
        ListView listaDeMedicos = findViewById(R.id.activity_lista_medicos_listview);
        listaDeMedicos.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_expandable_list_item_1,medicos, dao.todos()));


    }
}
