package com.example.androidpartefinal;

import android.content.Intent;
import android.os.Bundle;
import android.content.Context;

import com.example.androidpartefinal.ui.activity.OutraTela;

import androidx.appcompat.app.AppCompatActivity;
import android.view.View;

import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import android.util.Log;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import java.text.DecimalFormat;
import com.example.androidpartefinal.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {
    Button botaoFinalizar, botaoAbrirOutraTela;
    private AppBarConfiguration appBarConfiguration;
    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        botaoAbrirOutraTela=findViewById(R.id.btnAbrirOutraTela);
        botaoFinalizar=findViewById(R.id.btnAbrirOutraTela);

        botaoFinalizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        botaoAbrirOutraTela.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent outraTela=new Intent(getApplicationContext(), OutraTela.class);
                startActivity(outraTela);
            }
        });



        final EditText etPeso = findViewById(R.id.etPeso);
        final EditText etAltura = findViewById(R.id.etAltura);
        Button btnCalc = findViewById(R.id.btnCalc);
        Button btnClear = findViewById(R.id.btnClear);
        final TextView tvResp = findViewById(R.id.tvResp);

        // Botão para calcular
        btnCalc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    double imc = calcIMC(Double.parseDouble(etPeso.getText().toString()), Double.parseDouble(etAltura.getText().toString()));
                    imcString(imc, tvResp);
                }
                catch (Exception e) {
                    Log.d("Erro:",e.toString());
                    tvResp.setText(getText(R.string.err));
                }
                hideKeyBoard();
            }
        });
        // Botão limpar
        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etPeso.setText("");
                etAltura.setText("");
                tvResp.setText("");
            }
        });
    }
    // Cálculo do IMC
    private double calcIMC(double peso, double altura){
        double resp = peso/(altura*altura);
        return resp;
    }
    // Obtem cálculo e formula resposta
    private void imcString(double calc,TextView tv){
        DecimalFormat df = new DecimalFormat("#.00");
        String resp = "IMC: "+df.format(calc)+"\n";
        if(calc < 17){
            resp+= getText(R.string.resp_1);
            tv.setTextColor(getResources().getColor(R.color.color1));
        }
        else if(calc >= 17 && calc < 18.5){
            resp+= getText(R.string.resp_2);
            tv.setTextColor(getResources().getColor(R.color.color2));
        }
        else if(calc >= 18.5 && calc < 25){
            resp+= getText(R.string.resp_3);
            tv.setTextColor(getResources().getColor(R.color.color3));
        }
        else if(calc >= 25 && calc < 30){
            resp+= getText(R.string.resp_4);
            tv.setTextColor(getResources().getColor(R.color.color4));
        }
        else if(calc >= 30 && calc < 35){
            resp+= getText(R.string.resp_5);
            tv.setTextColor(getResources().getColor(R.color.color5));
        }
        else if(calc >= 35 && calc < 40){
            resp+= getText(R.string.resp_6);
            tv.setTextColor(getResources().getColor(R.color.color6));
        }
        else {
            resp+= getText(R.string.resp_7);
            tv.setTextColor(getResources().getColor(R.color.color7));
        }
        tv.setText(resp);
    }
    // Esconde o teclado
    public void hideKeyBoard() {
        View view = this.getCurrentFocus();
        if(view!= null){
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }
}