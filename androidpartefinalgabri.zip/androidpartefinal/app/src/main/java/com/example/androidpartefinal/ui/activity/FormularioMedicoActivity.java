package com.example.androidpartefinal.ui.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import com.example.androidpartefinal.R;
import com.example.androidpartefinal.ui.dao.MedicoDAO;

public class FormularioMedicoActivity extends AppCompatActivity {

    private String nome;
    private String telefone;
    private String area;

    public FormularioMedicoActivity(String nome) {
        this.nome = nome;
        FormularioMedicoActivity = null;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formulario_medico);

        final MedicoDAO dao = new MedicoDAO();



        final EditText campoNome = findViewById(R.id.activity_lista_medicos_fab_novo_medico_nome);
        final EditText campoTelefone = findViewById(R.id.activity_lista_medicos_fab_novo_medico_telefone);
        final EditText campoArea = findViewById(R.id.activity_lista_medicos_fab_novo_medico_nome);

    }
        Button botaoSalvar = findViewById(R.id.activity_lista_medicos_fab_novo_medico_botao_salvar);
        botaoSalvar.setOnClickListener(view)
    private final Object FormularioMedicoActivity;

    {
                String nome = campoNome.getText().toString();
                String telefone = campoTelefone.getText().toString();
                String area = campoArea.getText().toString();

                Medicos medicosCriado = new Medicos(nome, telefone, area);
                dao.salva(medicosCriado);

                startActivity(new Intent(FormularioMedicoActivity, com.example.androidpartefinal.ui.activity.FormularioMedicoActivity.class));


            }
        };


    }